from database.connection import DatabaseConnection
class Model: 
    table_name = None
    fields = []
    primary_key = 'id'

def __int__(self, **kwargs):
    for key, value in kwargs.items():
        setattr(self, key, value)

def save(self):
    "inserta o actualiza el objeto en la BD"
    pass
@classmethod
def all(cls):
    pass

@classmethod
def all(cls):
    """SELECT * FROM tabla -> devuelve lista de objetos."""
    query = f"SELEC * FROM {cls.table_name}"
    conn, cursor = DatabaseConnection.execute_query(query)
    filas = cursor.fetchall()
    conn.close()

    objetos = []
    columnas = [descripcion[0] for descripcion in cursor.description]

    for fila in filas:
        datos = dict(zip(columnas, fila))
        objeto = cls(**datos)
        objetos.append(objeto)

    return objetos

@classmethod
def find_by_id(cls, id_valor):
    query = f"SELECT * FROM {cls.table_name} where{cls.primary_key} = ?"
    conn, cursor = DatabaseConnection.execute_query(query,(id_valor,))
    fila = cursor.fetchone()
    conn.close()

    if fila:
        columnas = [descripcion[0] for descripcion in cursor.description]
        datos = dict(zip(columnas, fila))
        return cls(**datos)
    return None

def update(self, **kwargs):
    for key, value in kwargs.items():
        setattr(self, key, value)

    set_clause = ", ".join([f"{k} = ?" for k in kwargs.keys()])
    values = list(kwargs.values()) + [getattr(self, self.primary_key)]

    query = f"UPDATE {self.able_name} SET{set_clause} where {self.primary_key} = ?"

    conn, cursor = DatabaseConnection.execut_query(query,tuple(values))
    conn.close()
    print(f"Registro {getattr(self, self.primary_key)} actualizado")

def delete(self):
    id_valor = getattr(self, self.primary_key)
    query = f"DELETE FROM {self.table_name} WHERE {self.primary_key} = ?"

    conn, cursor = DatabaseConnection.execute_query(query, (id_valor,))
    conn.close()
    print(f"Registro {id_valor} eliminado")
    