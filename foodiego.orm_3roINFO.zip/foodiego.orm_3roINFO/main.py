from database.connection import DatabaseConnection
from models.cliente import Cliente

DatabaseConnection.initialize_tables()

c1 = Cliente(
    nombre="Ana",
    apellido="Gómez",
    email="ana@gmail.com",
    telefono="555-1234",
    direccion_entrega="Calle Falsa 123"
)
c1.save()

c2 = Cliente(
    nombre="Luis",
    apellido="Pérez",
    email="luis@email.com",
    telefono="555-5678",
    direccion_entrega="Calle 2"
)
c2.save()

print("\n--- Todos los clientes ---")
todos = Cliente.all()
for cliente in todos:
    print(f"ID: {cliente.id_cliente}, Nombre: {cliente.nombre} {cliente.apellido}")
    print(f"  Email: {cliente.email}, Fecha registro: {cliente.fecha_registro}")

print("\n--- Buscar cliente ID 1 ---")
cliente_buscado = Cliente.find_by_id(1)
print(f"Email: {cliente_buscado.email}")

c1.update(telefono="55-9999")

print("\n--- Después del UPDATE ---")
for c in Cliente.all():
    print(f"{c.id_cliente}: {c.nombre} - {c.telefono}")

c1.delete()

print("\n--- Después del DELETE ---")
for c in Cliente.all():
    print(f"{c.id_cliente}: {c.nombre}")